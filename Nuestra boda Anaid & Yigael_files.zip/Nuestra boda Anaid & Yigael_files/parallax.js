
jarallax(document.querySelectorAll('.jarallax'), {
    speed: 0.2
});